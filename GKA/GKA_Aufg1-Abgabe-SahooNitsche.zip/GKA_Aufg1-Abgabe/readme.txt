Die gegebene zip-Datei ist das Eclipse Projekt.
Sie brauchen Eclipse f�r Java um dann das zip als Projekt in Eclipse zu importieren.
Die in Eclipse zu startende Datei ist "src/A1_test/AIGraphTest.java".
Mitgegeben ist auch der Dokumentationskopf.