package GKA_A3;

import GKA_A1.IAIGraph;

public class EdmondsKarp {

	private EdmondsKarp() {
	}

	public static IAIGraph edmondsKarp(IAIGraph graph) {
		return algo(graph);
	}

	private static IAIGraph algo(IAIGraph graph) {
		return graph;
	}
	
}
