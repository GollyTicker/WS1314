package GKA_A3;

import GKA_A1.IAIGraph;

public class FordFulkerson {

	private FordFulkerson() {
	}

	public static IAIGraph fordFulkerson(IAIGraph graph) {
		return algo(graph);
	}

	private static IAIGraph algo(IAIGraph graph) {
		return graph;
	}
	
}
