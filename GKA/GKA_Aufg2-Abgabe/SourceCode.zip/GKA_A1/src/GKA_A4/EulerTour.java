package GKA_A4;

public class EulerTour {

}
